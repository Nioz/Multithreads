package scalarProduct;

/*
 * Nicholas B
 */

public class PrimeCalculatorThreadTest {

	public static void main(String[] args) throws InterruptedException {
		Thread ct = Thread.currentThread();
		System.out.println("Main thread name: " + ct.getName());
		int firstNum = 1;
		int lastNum = 20; //Greater value increases duration
		int numOfThreads = 3;
		int numOfFoundPrimeNumbers = 0;
		
		//Calculates range to be used by threads
		int range= (int)(lastNum - firstNum  +1) / numOfThreads;
		
		
		long startTime = System.currentTimeMillis();
		
		//Creating Threads
		PrimeCalculatorThread threads [] = new PrimeCalculatorThread[numOfThreads];
		
		int init = -1, end = -1;
		
		//Creates
		for(int i = 0; i < numOfThreads; i++) {
			//Assigning, end, and creating threads
				init = i * range + firstNum;
				end = (i < numOfThreads - 1) ? (init + range - 1) : (lastNum);
				
				threads[i] = new PrimeCalculatorThread(init, end);
			}
			
			//Starts each thread
			for(int i = 0; i < numOfThreads; i++) {
				threads[i].start();
			}
			
			//Synchronizes threads
			for (int i = 0; i < numOfThreads; i++) {
				threads[i].join();
			}
			

		
		
		long curTime = System.currentTimeMillis();
		long duration = (curTime - startTime) / 1000;
		
		//adding to counter of number of prime numbers
		for(int i = 0; i < numOfThreads; i++) {
			numOfFoundPrimeNumbers += threads[i].getNumPrimeNumbers();
		}
		
		//Prints out how many prime numbers were found and how long it took to calculate
		System.out.println("Result = " + numOfFoundPrimeNumbers + " Duration: " + duration);
		
		
		//Prints out prime numbers found in the range
		System.out.println("Prime Number(s): ");
		for(int i = 0; i < numOfThreads; i++) {
			System.out.println(threads[i].getPrimeNumbers() + " ");
		}
		
		
		
		
		

	}


}
