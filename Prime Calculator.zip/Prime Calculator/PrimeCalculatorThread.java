package scalarProduct;
import java.util.*;

/*
 * Nicholas B
 */

public class PrimeCalculatorThread extends Thread {
	private int begin, end, numOfFoundPrimeNumbers;
	private ArrayList<Integer> primeNumberList;
	
	private final static int MIN_WAIT = 1; //to simulate a random wait
	private final static int MAX_WAIT = 3; //to simulate a random wait
	private Random random;
	
	//PrimeCalc Constructor
	public PrimeCalculatorThread(int begin, int end) {
		super();
		numOfFoundPrimeNumbers = 0;
		this.begin = begin;
		this.end = end;
		primeNumberList = new ArrayList<Integer>();
		
		random = new Random(); //to be added to simulate a random wait
		} //End Constructor
	
	//Run method that calculates whether or not items in threads are prime
	public void run() {
		boolean isPrime;
		int j;
		
		//Prints out range that each thread is handling when the thread starts
		System.out.println(Thread.currentThread().getName() + " [" + begin + "," + end + "] started.");
		
		for(int curNumber = begin; curNumber <= end; curNumber++) {
			isPrime = true;
			if(curNumber == 1)
				isPrime = false;
			for(j = 2; j < curNumber; j++) {
				if(curNumber % j == 0)
					isPrime = false;
			}
			if(isPrime) {
				numOfFoundPrimeNumbers++;
				primeNumberList.add(curNumber);
				randomWait();
			} //End Run
			
		}
		System.out.println(Thread.currentThread().getName() + "... " + Thread.currentThread().getName() + "[ " + begin + ","  + end + "] completed.");
	}
	
	
	/********************Getters***************************/
	//Returns int of how many prime numbers were found
	public int getNumPrimeNumbers() {
		return numOfFoundPrimeNumbers;
	} //End getNumPrimeNumbers
	
	//Finds, stores, and returns the prime number that was found
	public String getPrimeNumbers() {
		String s = "";
		for(int i = 0; i < primeNumberList.size(); i++)
			s += primeNumberList.get(i) + " ";
		return s;
	}// End getPrimeNumbers
	
	/*******************************************************/
	
	//This is implementing an I/O burst to make the CPU more efficient
	private void randomWait() {
		try {
			int randomTime = random.nextInt(MAX_WAIT - MIN_WAIT + 1) + MIN_WAIT;
			Thread.sleep(randomTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	} //End randomWait
	
	
	
	

}
